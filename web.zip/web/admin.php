<?php
session_start();

// ==========================================
// KONFIGURASI PASSWORD ADMIN (UBAH INI)
// ==========================================
$ADMIN_PASSWORD = "hokageadmin123"; 

// --- Proses Logout ---
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// --- Proses Login Admin ---
$login_err = "";
if (isset($_POST['login_admin'])) {
    if ($_POST['password'] === $ADMIN_PASSWORD) {
        $_SESSION['is_admin'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $login_err = "Password Admin Salah!";
    }
}

// --- Halaman Login (Jika belum login) ---
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8"><title>Admin Login - Hokage Legend</title>
        <style>
            body { background: #0f2027; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .box { background: rgba(255,255,255,0.1); padding: 40px; border-radius: 10px; text-align: center; border: 1px solid #f39c12; }
            input { padding: 10px; width: 100%; margin: 10px 0; border-radius: 5px; border: none; }
            button { padding: 10px; width: 100%; background: #f39c12; color: #111; font-weight: bold; border: none; cursor: pointer; border-radius: 5px;}
        </style>
    </head>
    <body>
        <div class="box">
            <h2 style="color: #f39c12;">👑 ADMIN PANEL</h2>
            <p style="color: #ff4757;"><?= $login_err ?></p>
            <form method="POST">
                <input type="password" name="password" placeholder="Masukkan Password Admin" required>
                <button type="submit" name="login_admin">Masuk Panel</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ==========================================
// KONEKSI DATABASE & LOGIK CRUD
// ==========================================
$db_file = '/var/www/html/web_users.db';
$db = new PDO("sqlite:" . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$msg = "";

// 1. CREATE USER
if (isset($_POST['add_user'])) {
    $tid = trim($_POST['telegram_id']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    try {
        $stmt = $db->prepare("INSERT INTO web_users (telegram_id, password) VALUES (?, ?)");
        $stmt->execute([$tid, $pass]);
        $msg = "<div class='alert success'>✅ User berhasil ditambahkan!</div>";
    } catch (Exception $e) {
        $msg = "<div class='alert error'>❌ Gagal: Username mungkin sudah ada.</div>";
    }
}

// 2. UPDATE USER
if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $tid = trim($_POST['telegram_id']);
    $new_pass = $_POST['password'];

    if (!empty($new_pass)) {
        // Update username & password
        $pass = password_hash($new_pass, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE web_users SET telegram_id = ?, password = ? WHERE id = ?");
        $stmt->execute([$tid, $pass, $id]);
    } else {
        // Update username saja
        $stmt = $db->prepare("UPDATE web_users SET telegram_id = ? WHERE id = ?");
        $stmt->execute([$tid, $id]);
    }
    $msg = "<div class='alert success'>✅ Data User berhasil diupdate!</div>";
}

// 3. DELETE USER
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $db->prepare("DELETE FROM web_users WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin.php?msg=deleted");
    exit;
}
if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') {
    $msg = "<div class='alert success'>✅ User berhasil dihapus!</div>";
}

// AMBIL SEMUA DATA (READ)
$users = $db->query("SELECT * FROM web_users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Hokage Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --primary: #f39c12; --bg: #0f2027; --panel: rgba(255,255,255,0.05); }
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background: var(--bg); color: #fff; padding: 20px; }
        .container { max-width: 900px; margin: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--primary); padding-bottom: 10px; margin-bottom: 20px; }
        .card { background: var(--panel); border: 1px solid rgba(255,255,255,0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.1); }
        th { color: var(--primary); }
        
        input { padding: 10px; border-radius: 5px; border: 1px solid #555; background: rgba(0,0,0,0.5); color: #fff; width: 100%; margin-bottom: 10px; }
        .btn { padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; color: #111; text-decoration: none; display: inline-block;}
        .btn-add { background: #2ecc71; } .btn-edit { background: var(--primary); } .btn-del { background: #e74c3c; color: #fff; } .btn-logout { background: #e74c3c; color:#fff; }
        
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .success { background: rgba(46, 204, 113, 0.2); border: 1px solid #2ecc71; color: #2ecc71; }
        .error { background: rgba(231, 76, 60, 0.2); border: 1px solid #e74c3c; color: #e74c3c; }
        
        /* Modal Style */
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); align-items: center; justify-content: center; }
        .modal-content { background: #1a252f; padding: 30px; border-radius: 10px; border: 1px solid var(--primary); width: 400px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>👑 Hokage Admin Panel</h2>
            <a href="?logout=true" class="btn btn-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <?= $msg ?>

        <div class="card">
            <h3 style="margin-top:0; color: var(--primary);"><i class="fas fa-plus-circle"></i> Tambah User Baru</h3>
            <form method="POST" style="display: flex; gap: 10px;">
                <input type="text" name="telegram_id" placeholder="Username / ID Telegram" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" name="add_user" class="btn btn-add" style="width: 150px;">Tambah</button>
            </form>
        </div>

        <div class="card">
            <h3 style="margin-top:0; color: var(--primary);"><i class="fas fa-users"></i> Daftar Web Users (<?= count($users) ?>)</h3>
            <div style="overflow-x: auto;">
                <table>
                    <tr>
                        <th>ID DB</th>
                        <th>Username / ID Telegram</th>
                        <th>Hash Password</th>
                        <th>Aksi</th>
                    </tr>
                    <?php if (count($users) > 0): ?>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td><?= $u['id'] ?></td>
                            <td><strong><?= htmlspecialchars($u['telegram_id']) ?></strong></td>
                            <td style="font-size: 0.8em; color: #888;">...<?= substr($u['password'], -15) ?></td>
                            <td>
                                <button onclick="editUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['telegram_id']) ?>')" class="btn btn-edit"><i class="fas fa-edit"></i> Edit</button>
                                <a href="?delete=<?= $u['id'] ?>" onclick="return confirm('Yakin hapus user ini?');" class="btn btn-del"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align: center; color: #888;">Belum ada user yang mendaftar.</td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content">
            <h3 style="color: var(--primary); margin-top: 0;">Edit User</h3>
            <form method="POST">
                <input type="hidden" id="edit_id" name="id">
                <label style="color:#aaa; font-size: 0.9em;">Username:</label>
                <input type="text" id="edit_username" name="telegram_id" required>
                
                <label style="color:#aaa; font-size: 0.9em;">Password Baru (Kosongkan jika tidak diubah):</label>
                <input type="password" name="password" placeholder="***">
                
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button type="submit" name="update_user" class="btn btn-add" style="flex: 1;">Simpan Update</button>
                    <button type="button" onclick="closeModal()" class="btn btn-del" style="flex: 1;">Batal</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function editUser(id, username) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_username').value = username;
            document.getElementById('editModal').style.display = 'flex';
        }
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }
    </script>
</body>
</html>
